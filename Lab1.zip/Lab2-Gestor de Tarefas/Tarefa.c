#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Códigos de comando
enum Command {
    CMD_NEW,
    CMD_LIST,
    CMD_COMPLETE,
    CMD_EXIT,
    CMD_UNKNOWN
};

// Função para obter o comando a partir da entrada do usuário
enum Command get_command(const char *input) {
    if (strncmp(input, "new", 3) == 0) {
        return CMD_NEW;
    } else if (strncmp(input, "list", 4) == 0) {
        return CMD_LIST;
    } else if (strncmp(input, "complete", 8) == 0) {
        return CMD_COMPLETE;
    } else if (strncmp(input, "exit", 4) == 0 || strncmp(input, "quit", 4) == 0) {
        return CMD_EXIT;
    } else {
        return CMD_UNKNOWN;
    }
}


// Define uma estrutura para tarefas
typedef struct Task {
    char task_id[100];
    int priority;
    time_t creation_time; // Nova adição para armazenar a data de criação da tarefa
    struct Task *next;
} Task;

// Define uma estrutura para o gestor de tarefas
typedef struct {
    Task *head[6]; // Lista ligada para cada nível de prioridade
} TaskManager;

// Inicializa o gestor de tarefas
void initialize(TaskManager *manager) {
    for (int i = 0; i < 6; i++) {
        manager->head[i] = NULL;
    }
}

// Verifica se uma tarefa com o ID fornecido já existe
int task_exists(TaskManager *manager, const char *task_id) {
    for (int i = 0; i < 6; i++) {
        Task *current = manager->head[i];
        while (current != NULL) {
            if (strcmp(current->task_id, task_id) == 0) {
                return 1;
            }
            current = current->next;
        }
    }
    return 0;
}

// Adiciona uma nova tarefa
void add_task(TaskManager *manager, int priority, const char *task_id) {
    if (priority < 0 || priority > 5) {
        printf("Prioridade inválida.\n");
        return;
    }
    
    if (task_exists(manager, task_id)) {
        printf("A tarefa já existe.\n");
        return;
    }
    
    if (strlen(task_id) == 0) {
        printf("ID da tarefa vazio.\n");
        return;
    }

    Task *new_task = (Task*)malloc(sizeof(Task));
    if (new_task == NULL) {
        printf("Memória insuficiente.\n");
        return;
    }
    
    strcpy(new_task->task_id, task_id);
    new_task->priority = priority;
    new_task->creation_time = time(NULL); // Define a data de criação como o tempo atual
    new_task->next = manager->head[priority];
    manager->head[priority] = new_task;
    
    printf("Tarefa adicionada com sucesso.\n");
}

// Lista tarefas com prioridade maior ou igual à prioridade mínima

// Lista tarefas com prioridade maior ou igual à prioridade mínima
void list_tasks(TaskManager *manager, int min_priority) {
    if (min_priority < 0 || min_priority > 5) {
        printf("Prioridade inválida.\n");
        return;
    }

    int tasks_found = 0; // Variável para rastrear se foram encontradas tarefas

    for (int i = 5; i >= min_priority; i--) {
        // Array temporário para armazenar as tarefas para ordenação
        Task *temp_tasks[100]; // Suponha que haverá no máximo 100 tarefas por prioridade
        int count = 0;

        // Preenche o array temporário com as tarefas da lista
        Task *current = manager->head[i];
        while (current != NULL) {
            temp_tasks[count++] = current;
            current = current->next;
            tasks_found = 1; // Indica que foram encontradas tarefas
        }

        // Ordena o array de tarefas por prioridade e, em caso de empate, por data de criação
        for (int j = 0; j < count - 1; j++) {
            for (int k = j + 1; k < count; k++) {
                if (temp_tasks[j]->priority < temp_tasks[k]->priority ||
                    (temp_tasks[j]->priority == temp_tasks[k]->priority && 
                     difftime(temp_tasks[j]->creation_time, temp_tasks[k]->creation_time) < 0)) {
                    Task *temp = temp_tasks[j];
                    temp_tasks[j] = temp_tasks[k];
                    temp_tasks[k] = temp;
                }
            }
        }

        // Imprime as tarefas ordenadas
        for (int j = 0; j < count; j++) {
            printf("Tarefa ID: %s, Priority: %d\n", temp_tasks[j]->task_id, temp_tasks[j]->priority);
        }
    }

    // Verifica se foram encontradas tarefas e exibe a mensagem apropriada
    if (tasks_found) {
        printf("Listagem concluída.\n");
    } else {
        printf("Nenhuma tarefa encontrada com a prioridade especificada.\n");
    }
}




// Completa uma tarefa
void complete_task(TaskManager *manager, const char *task_id) {
    if (strlen(task_id) == 0) {
        printf("ID da tarefa vazio.\n");
        return;
    }

    for (int i = 0; i < 6; i++) {
        Task *current = manager->head[i];
        Task *prev = NULL;
        
        while (current != NULL) {
            if (strcmp(current->task_id, task_id) == 0) {
                // Remove a tarefa
                if (prev != NULL) {
                    prev->next = current->next;
                } else {
                    manager->head[i] = current->next;
                }
                free(current);
                printf("Tarefa concluída com sucesso.\n"); // Mensagem de tarefa concluída
                return;
            }
            prev = current;
            current = current->next;
        }
    }
    printf("TAREFA INEXISTENTE\n");
}

// Libera a memória alocada
void cleanup(TaskManager *manager) {
    for (int i = 0; i < 6; i++) {
        Task *current = manager->head[i];
        while (current != NULL) {
            Task *temp = current;
            current = current->next;
            free(temp);
        }
        manager->head[i] = NULL;
    }
}
int main() {
    TaskManager manager;
    initialize(&manager);

    char input[100];
    int priority;
    char task_id[100];

    printf("Bem-Vindoos ao Gestor de tarefas!\n");
    printf("Comandos disponiveis:\n");
    printf(" - new <priority> <new-task-id>\n");
    printf(" - list <priority>\n");
    printf(" - complete <task-id>\n");
    printf(" - exit\n");

    while (1) {
        printf("\nDigite um comando: ");
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = '\0'; // Remove a quebra de linha

        if (strlen(input) == 0) {
            printf("Comando vazio, por favor, digite um comandp\n");
            continue;
        }

        enum Command cmd = get_command(input);

        switch (cmd) {
            case CMD_NEW:
                if (sscanf(input, "new %d %s", &priority, task_id) == 2) {
                    add_task(&manager, priority, task_id);
                } else {
                    printf("Uso correcto: new <priority> <new-task-id>\n");
                }
                break;
            case CMD_LIST:
                if (sscanf(input, "list %d", &priority) == 1) {
                    list_tasks(&manager, priority);
                } else {
                    printf("Uso correcto: list <priority>\n");
                }
                break;
            case CMD_COMPLETE:
                if (sscanf(input, "complete %s", task_id) == 1) {
                    complete_task(&manager, task_id);
                } else {
                    printf("Uso correcto: complete <task-id>\n");
                }
                break;
            case CMD_EXIT:
                cleanup(&manager);
                printf("Exiting the system...\n");
                exit(0);
            case CMD_UNKNOWN:
                printf("Comando desconhecido. por favor, tente de novo.\n");
                break;
        }
    }

    return 0;
}